
  

  function startGame(myGame) { 


    
    background = new Image();	
    background.src = "images/background2.png";
    var bgImg = new DrawImage(0, 0 ,1000, 700, background);
    myGame.addSprite(bgImg);

    bigPlanet = new Image();	
    bigPlanet.src = "images/parallax-space-big-planet.png";
    var bigPlanet = new DrawImage(200, -700 ,250, 250, bigPlanet);
    bigPlanet.setMover(true);
    myGame.addSprite(bigPlanet);

    var star = new Image();	
    star.src = "images/parallax-space-stars.png";
    var star0 = new DrawImage(0, -2000 ,500, 350, star);
    star0.setMover(true);
    myGame.addSprite(star0);


    var star10 = new DrawImage(0, -1250 ,500, 350, star);
    star10.setMover(true);
    myGame.addSprite(star10);


    var stars11 = new DrawImage(500, -750 ,500, 350, star);
    stars11.setMover(true);
    myGame.addSprite(stars11);

    var stars12 = new DrawImage(0, -750 ,500, 350, star);
    stars12.setMover(true);
    myGame.addSprite(stars12);


    var stars13 = new DrawImage(500, -750 ,500, 350, star);
    stars13.setMover(true);
    myGame.addSprite(stars13);


    var stars7 = new DrawImage(0, -750 ,500, 350, star);
    stars7.setMover(true);
    myGame.addSprite(stars7);

    var stars8 = new DrawImage(500, -750 ,500, 350, star);
    stars8.setMover(true);
    myGame.addSprite(stars8);


    var star2 = new DrawImage(600, -500 ,500, 350, star);
    star2.setMover(true);
    myGame.addSprite(star2);


    var star3 = new DrawImage(0, 0 ,500, 350, star);
    star3.setMover(true);
    myGame.addSprite(star3);

    var star4 = new DrawImage(600, 0 ,500, 350, star);
    star4.setMover(true);
    myGame.addSprite(star4);

    var star5 = new DrawImage(0, -1000 ,500, 350, star);
    star5.setMover(true);
    myGame.addSprite(star5);

    var star1 = new DrawImage(600, -1000 ,500, 350, star);
    star1.setMover(true);
    myGame.addSprite(star1);

    twoPlanets = new Image();	
    twoPlanets.src = "images/parallax-space-far-planets.png";
    var twoPlanets = new DrawImage(0, -1000 ,500, 300, twoPlanets);
    twoPlanets.setMover(true);
    myGame.addSprite(twoPlanets);

    saturn = new Image();	
    saturn.src = "images/parallax-space-ring-planet.png";
    var saturn = new DrawImage(560, -1000 ,100, 200, saturn);
    saturn.setMover(true);
    myGame.addSprite(saturn);

    twoPlanets2 = new Image();	
    twoPlanets2.src = "images/parallax-space-far-planets.png";
    var twoPlanets2 = new DrawImage(300, -500 ,500, 300, twoPlanets2);
    twoPlanets2.setMover(true);
    myGame.addSprite(twoPlanets2);
    
    saturn2 = new Image();	
    saturn2.src = "images/parallax-space-ring-planet.png";
    var saturn2 = new DrawImage(700, -500 ,100, 200, saturn2);
    saturn2.setMover(true);
    myGame.addSprite(saturn2);
    
  
    
    player = new Image();	
    player.src = "images/enemy2.png";
    var player = new Player(400, 610 ,70, 70, player, myGame);
    myGame.addSprite(player);
    BulletSpawner = new Image();	
    BulletSpawner.src = "images/lazer.png";
    var BulletSpawner = new PlayerBullet(player.x, player.y ,50, 70, BulletSpawner, player, true);
    myGame.addSprite(BulletSpawner);

    
    enemySpawner = new Image();	
    enemySpawner.src = "images/enemy.png";
    var enemySpawner = new Enemy(400, 100 ,150, 150, enemySpawner, true , myGame);
    myGame.addSprite(enemySpawner);

    var heart = new Image();
    heart.src = "images/heart.png";
    var heart1 = new DrawImage(930 , 0 , 75 , 75,heart);
    myGame.addSprite(heart1);
    myGame.hearts.push(heart1);
    var heart2 = new DrawImage(890 , 0 , 75 , 75,heart);
    myGame.addSprite(heart2);
    myGame.hearts.push(heart2);
    var heart3 = new DrawImage(850 , 0 , 75 , 75,heart);
    myGame.addSprite(heart3);
    myGame.hearts.push(heart3);
    
    
    

    

    
    arrows = new Image();	
    arrows.src = "images/arrows.png";
    var arrows = new DrawImage(920, 650 ,60, 40, arrows);
    myGame.addSprite(arrows);

    spaceKey = new Image();	
    spaceKey.src = "images/spaceKey.png";
    var spaceKey = new DrawImage(750, 610 , 200, 140, spaceKey);
    myGame.addSprite(spaceKey);

    


    myGame.playing.play();
    animate(myGame);
  };
var paused = false;
function animate(myGame) { // a recursive fucntion that updates and draws the sprites.
	if(80 in keysDown)
  {
       paused = true;
       pausedImg = new Image();	
       pausedImg.src = "images/paused.png";
       myGame.ctx.drawImage(pausedImg, 230, -100, 550, 400);
       myGame.ctx.font = "30px  monospace";
       myGame.ctx.fillStyle = "#F39C12";
       myGame.ctx.fillText(`Press C to resume`, 370, 200);
  }
  if(67 in keysDown)
  {
       paused = false;
  }
  if(!paused){
  if(!myGame.gameEnded){
    if((myGame.playing.duration > 0 && !myGame.playing.paused))
    {
      
    }else if(!myGame.gameOver && !myGame.enemyBossIntiated)
    {
      myGame.playing.play();
    }
    
      myGame.update();
      myGame.draw();
  
        requestAnimFrame(function() {
          animate(myGame);
        });
      }else 
      {
        
        myGame.playing.pause();
        myGame = new game(800, 1000);
        startGame(myGame);
        return;
      }}
      else{
        requestAnimFrame(function() {
          animate(myGame);
        });
      }
}
      
      
  SpaceShooter = new game(800, 1000);
startGame(SpaceShooter); // starting the game