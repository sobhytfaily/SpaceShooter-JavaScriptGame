
window.requestAnimFrame = (function (callback) {
  return window.requestAnimationFrame || window.webkitRequestAnimationFrame || window.mozRequestAnimationFrame || window.oRequestAnimationFrame || window.msRequestAnimationFrame ||
    function (callback) {
      window.setTimeout(callback, 1000 / 60);
    };
})();


var counter = 0;
var explosionImg = new Image();
explosionImg.src = "images/explosion3.png";
class game {
  constructor(canvasWidth, canvasHeight) {
    this.canvas = document.getElementById("mainGame");
    if (this.canvas.getContext) {
      this.ctx = this.canvas.getContext("2d");
    }
    this.bullets = [];
    this.enemyBullets = [];
    this.enemys = [];
    this.sprites = [];
    this.hearts = [];
    this.score = 0;
    this.gameEnded = false;
    this.gameWon = false;
    this.enemiesKilled = 0;
    this.gameOver = false;
    this.invincibleOn = false;
    this.cw = canvasWidth;
    this.ch = canvasHeight;
    this.playing = new Audio();
    this.enemyBossIntiated = false;
    this.playing.src = "sound/BattleintheStars.ogg";
    this.playing.play();
    

  }
  addSprite(sprite) {
    this.sprites.push(sprite);
  }
  update() {
    var ldeletedArray = [];
    var lSpritesLength = this.sprites.length;
    for (var i = 0; i < lSpritesLength; i++) {
      var value = this.sprites[i].update();
      if (value == true) {
        ldeletedArray.push(this.sprites[i]);
      }
      if (value instanceof PlayerBullet) {
        this.bullets.push(value);
        this.addSprite(value);
      }
      if (value instanceof Enemy && !this.enemys.includes(value)) {
        this.enemys.push(value);
        this.sprites.push(value);
      }
    }
    if(!this.gameWon)
    if (!this.gameOver) {
      for (let i = 0; i < this.enemyBullets.length; i++) {
        if ((this.enemyBullets[i].getY() > this.sprites[18].getY()) && (this.enemyBullets[i].getY() < this.sprites[18].getY() + 10)
          && (this.enemyBullets[i].getX() > this.sprites[18].getX() - 10 && this.enemyBullets[i].getX() < this.sprites[18].getX() + 70)) {

          if (this.hearts.length != 1) {
            if(!this.sprites[18].invincible){
            var sound = new Audio();
            sound.src = "sound/heartLoss.wav";
            sound.play();
            
            var heart = this.hearts.pop();
            ldeletedArray.push(heart);
            }
            else{
              var sound = new Audio();
              sound.src = "sound/hittingShield.wav";
              sound.play();
            }
            ldeletedArray.push(this.enemyBullets[i]);
            this.enemyBullets.splice(i, 1);

          } 
          else
          {
            if(!this.sprites[18].invincible){
            var sound = new Audio();
            sound.src = "sound/heartLoss.wav";
            sound.play();
            var sound = new Audio();
            sound.src = "sound/playerLose.wav";
            sound.play();
            var heart = this.hearts.pop();
            ldeletedArray.push(heart);
            ldeletedArray.push(this.enemyBullets[i]);
            this.enemyBullets.splice(i, 1);
            var bg = new Image();
            bg.src = "images/gameOver.png";
            var bg = new DrawImage(180, -500, 700, 600, bg, this, 0);
            bg.setMover(true);
            this.addSprite(bg);
            this.gameOver = true;
            }
            else{
              var sound = new Audio();
              sound.src = "sound/hittingShield.wav";
              sound.play();
              ldeletedArray.push(this.enemyBullets[i]);
            this.enemyBullets.splice(i, 1);
            }
          }

          if (this.gameOver) {
            ldeletedArray.push(this.sprites[19]);
            var explosion = new spriteImage({
              width: 791,
              height: 315,
              x: this.sprites[18].getX(),
              y: this.sprites[18].getY(),
              image: explosionImg,
              numberOfFramesx: 5,
              numberOfFramesy: 2,
              ticksPerFrame: 3,
              modifier: 1.5
            })

            this.addSprite(explosion);
            this.sprites[18].first = false;
            this.sprites[18].destoyed = true;
            ldeletedArray.push(this.sprites[18]);
            var gameOverMusic = new Audio();
            gameOverMusic.src = "sound/Defeated.ogg";
            this.playing.pause();
            setTimeout(function () { gameOverMusic.play() }, 1500);
          }
        }
      }

    }
    if(this.gameOver)
    {
      for (var i = 0; i < lSpritesLength; i++)
      {
        if(this.sprites[i] instanceof EnemyBoss)
          this.sprites[i].soundTrack.pause();
      }
    }
  
    if (!this.gameOver) {
      for (let i = 0; i < this.enemys.length; i++) {

        if ((this.enemys[i].getY() + 70 >= this.sprites[18].getY()) && (this.enemys[i].getY() <= this.sprites[18].getY())
          && (this.enemys[i].getX() - 30 <= this.sprites[18].getX() && this.enemys[i].getX() + 70 >= this.sprites[18].getX())) {

          var sound = new Audio();
          sound.src = "sound/heartLoss.wav";
          sound.play();
          var sound = new Audio();
          sound.src = "sound/playerLose.wav";
          sound.play();
          for (let i = 0; i < 3; i++) {
            if (this.hearts.length != 0) {
              var heart = this.hearts.pop();
              ldeletedArray.push(heart);
            }
            else {
              break;
            }
          }
          var bg = new Image();
          bg.src = "images/gameOver.png";
          var bg = new DrawImage(180, -500, 700, 600, bg, this, 0);
          bg.setMover(true);
          this.addSprite(bg);
          ldeletedArray.push(this.sprites[19]);
          var explosion = new spriteImage({
            width: 791,
            height: 315,
            x: (this.sprites[18].getX() + this.enemys[i].getX()) / 2,
            y: (this.sprites[18].getY() + this.enemys[i].getY()) / 2,
            image: explosionImg,
            numberOfFramesx: 5,
            numberOfFramesy: 2,
            ticksPerFrame: 3,
            modifier: 2.5
          })
          this.addSprite(explosion);

          this.sprites[18].first = false;
          this.sprites[18].destoyed = true;
          this.enemys[i].destoyed = true;
          ldeletedArray.push(this.sprites[18]);
          this.gameOver = true;
          var gameOverMusic = new Audio();
          gameOverMusic.src = "sound/Defeated.ogg";
          this.playing.pause();
          setTimeout(function () { gameOverMusic.play() }, 1500);

        }
      }
    }

    for (var i = 1; i < this.sprites.length; i++){
        if(this.sprites[i] instanceof EnemyBoss)
        {
          for (var j = 1; j < this.bullets.length; j++) 
          {
            
            if ((this.bullets[j].getY() < this.sprites[i].getY() + 170 && this.bullets[j].getY() > this.sprites[i].getY())
            && (this.bullets[j].getX() > this.sprites[i].getX() && this.bullets[j].getX() < this.sprites[i].getX() + 450))
            {
              var explosion = new spriteImage({
                width: 791,
                height: 315,
                x: this.bullets[j].getX(),
                y: this.bullets[j].getY(),
                image: explosionImg,
                numberOfFramesx: 5,
                numberOfFramesy: 2,
                ticksPerFrame: 3,
                modifier: .3
              })
              this.score += 20;
              this.addSprite(explosion);
              this.sprites[i].health--;
              this.bullets[j].toSplice = true;
              this.bullets[j].destoyed = true;
            }
          }
        }
      }
    for (var i = 0; i < this.enemys.length; i++) {
      for (var j = 1; j < this.bullets.length; j++) {
        if ((this.bullets[j].getY() < this.enemys[i].getY() + 50 && this.bullets[j].getY() > this.enemys[i].getY())
          && (this.bullets[j].getX() > this.enemys[i].getX() && this.bullets[j].getX() < this.enemys[i].getX() + 70)) {
 
            var explosion = new spriteImage({
            width: 791,
            height: 315,
            x: this.enemys[i].getX(),
            y: this.enemys[i].getY(),
            image: explosionImg,
            numberOfFramesx: 5,
            numberOfFramesy: 2,
            ticksPerFrame: 3
          })
          this.score += 1298;
          this.addSprite(explosion);
          this.enemys[i].toSplice = true;
          this.bullets[j].toSplice = true;
          this.enemys[i].destoyed = true;
          this.bullets[j].destoyed = true;
          this.enemiesKilled++;
          if (this.enemiesKilled % 6 == 0) {
            if(Math.random() < 0.5)
            {
              var powerUp = new consumable(this.enemys[i].x, this.enemys[i].y, 60, 60,this, this.sprites[18], 1);
            }
            else
            {
              var powerUp = new consumable(this.enemys[i].x, this.enemys[i].y, 60, 60,this, this.sprites[18], 2);
            }
            this.sprites.push(powerUp);
          }
        }

      }
      if(this.enemiesKilled == 12)
      {
        ldeletedArray.push(this.sprites[20]);
        var enemyBoss = new EnemyBoss(150, -1000, 450, 230, this);
        this.addSprite(enemyBoss);
        this.enemyBossIntiated = true;
        this.enemiesKilled++;
      }

    }
    for (let i = 0; i < this.bullets.length; i++) {
      if (this.bullets[i].getY() < -20) {
        this.bullets[i].destoyed = true;
        this.bullets[i].toSplice = true;
      }
    }
    for (var i = 0; i < ldeletedArray.length; i++) {
      var index = this.sprites.indexOf(ldeletedArray[i]);
      this.sprites.splice(index, 1);
    }
    for (var i = 1; i < this.bullets.length; i++) {
      if (this.bullets[i].getToSplice()) {
        this.bullets.splice(i, 1);
      }
    }
    for (var i = 0; i < this.enemyBullets.length; i++) {
      if (this.enemyBullets[i].toSplice) {
        this.enemyBullets.splice(i, 1);
      }
    }
    for (var i = 0; i < this.enemys.length; i++) {
      if (this.enemys[i].toSplice)
        this.enemys.splice(i, 1);
    }
    
  };
  draw() {
    var lSpritesLength = this.sprites.length;
    for (var i = 0; i < lSpritesLength; i++)
    this.sprites[i].draw(this.ctx);
    this.ctx.font = "20px monospace";
    this.ctx.fillStyle = "white";
    this.ctx.fillText("Score: " + this.score, 20, 30);
  }
};

class Sprite {
  constructor() {
  }
  update() {
  }
  draw(pCtx) {
  }
}

var keysDown = {};
addEventListener("keydown", function (e) { // to record user's input
  keysDown[e.keyCode] = true;
}, false);

addEventListener("keyup", function (e) { // to record user's input
  delete keysDown[e.keyCode];
}, false);

class Player extends Sprite {
  constructor(x, y, w, h, img, myGame) {
    super();
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.img = img;
    this.shield = new Image();
    this.shield.src = "images/shield.png";
    this.invincible = false;
    this.mover = false;
    this.destoyed = false;
    this.toSplice = false;
    this.timerBol = false;
    this.timer = 0;
    this.myGame = myGame;

  }
  update() {
    if(this.myGame.gameWon){
      this.y -= 2;
    }else{
    this.movement();
    if(this.invincible)
    {
      this.timer++;
    }
    if(this.timer == 1000)
    {
      this.invincible = false;
      this.timer = 0;
    }
  }}
  

  draw(ctx) {
    ctx.drawImage(this.img, this.x, this.y, this.w, this.h);
    if(this.invincible)
        ctx.drawImage(this.shield, this.x-25, this.y-20, this.w + 50, this.h + 50);

  }
  movement() {
    if (37 in keysDown || 65 in keysDown) {
      if (this.x > 1) {
        this.x -= 9;
      }
    }
    if (39 in keysDown || 68 in keysDown) {
      if (this.x < 930) {
        this.x += 9;
      }
    }
    if (38 in keysDown || 87 in keysDown) {
      if (this.y > 1) {
        this.y -= 9;
      }
    }
    if (40 in keysDown || 83 in keysDown) {
      if (this.y < 610) {
        this.y += 9;
      }
    }
  }
  getY() {
    return this.y;
  }
  getX() {
    return this.x;
  }
}

class Enemy extends Sprite {
  constructor(x, y, w, h, img, first, myGame) {
    super();
    this.x = x;
    this.y = y;
    this.w = w;
    this.myGame = myGame;
    this.h = h;
    this.img = img;
    this.deflectX = 0.7;
    this.first = first;
    this.enemyImg = new Image();
    this.enemyImg.src = "images/enemy.png";
    this.enemyImg1 = new Image();
    this.enemyImg1.src = "images/enemy3.png";
    this.bullet1 = new Image();
    this.bullet1.src = "images/lazer1.png";
    this.bullet = new Image();
    this.bullet.src = "images/lazer2.png";
    this.sound = new Audio();
    this.sound.src = "sound/enemyKill.mp3";
    this.destoyed = false;
    this.toSplice = false;
    this.fx = x;

  }
  update() {
    if (this.first)
      if (Math.random() < 0.005) {
        var value = Math.random() * 900;
        if(Math.random() > 0.5)
        {
          var enemy = new Enemy(value, -100, 100, 100, this.enemyImg1, false);
          var enemyGun = new EnemyBullet(value, -100, 50, 60, this.bullet1, enemy, this.myGame);
          this.myGame.enemyBullets.push(enemyGun);
          this.myGame.addSprite(enemyGun);
        }
        else{
          var enemy = new Enemy(value, -100, 100, 100, this.enemyImg, false);
          var enemyGun = new EnemyBullet(value, -100, 50, 60, this.bullet, enemy, this.myGame);
          this.myGame.enemyBullets.push(enemyGun);
          this.myGame.addSprite(enemyGun);
        }
        

        return enemy;
      }
    if (!this.first) {
      this.y += 2;

      if (this.x > this.fx + 50 || this.x < this.fx - 50) {
        this.deflectX = -this.deflectX;
      }
      this.x += this.deflectX;

      if (this.y > 700) {
        this.toSplice = true;
        return true;
      }
      if (this.destoyed) {
        this.sound.play();
        this.toSplice = true;
        return true;
      }

    }
  }
  draw(ctx) {
    if (!this.first) {
      ctx.drawImage(this.img, this.x, this.y, this.w, this.h);
    }
  }
  getY() {
    return this.y;
  }
  getX() {
    return this.x;
  }
}

class PlayerBullet extends Sprite {
  constructor(x, y, w, h, img, plane, first) {
    super();
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.img = img;
    this.plane = plane;
    this.first = first;
    this.destoyed = false;
    this.toSplice = false;
    this.bullet = new Image();
    this.bullet.src = "images/lazer.png";
    this.bullet1 = new Image();
    this.bullet1.src = "images/lazer3.png";
    this.sound = new Audio();
    this.sound.src = "sound/PlayerBullet.mp3";
    this.sound1 = new Audio();
    this.sound1.src = "sound/shoot2.wav";
    this.fireRateMode = 0;
    this.fireRate = 20;
    this.nextShotIn = 0;
    this.counter = 0;
  }

  update() {
    this.y -= 23;

    if (this.first && (this.fireRateMode == 0 || this.counter == 50)) {
      this.fireRate = 20;
      this.counter = 0;
      this.fireRateMode = 0;
    }
    else {
      this.fireRate = 5;
      this.fireRateMode = 1;
    }
    if (this.first) {
      if (32 in keysDown) {
        return this.fireBullet();
      }
    }
    if (!this.first) {
      if (this.destoyed) {
        return true;
      }
    }
  }
  draw(ctx) {
    if (!this.first) {
      ctx.drawImage(this.img, this.x, this.y, this.w, this.h);
    }
  }

  
  fireBullet() {
    if (this.nextShotIn > 0) {
      this.nextShotIn -= 1;
    }
    if (this.nextShotIn === 0) {
      
      if (this.fireRateMode == 1) {
        var bullet = this.fastFiring();
      }
      else {
        var bullet = this.slowFiring(bullet);
      }
      return bullet;
    }
  }


  slowFiring(bullet) {
    this.sound1.play();
    var bullet = new PlayerBullet(this.plane.x + 21, this.plane.y - 20, 30, 50, this.bullet, this.plane, this.enemy, false);
    this.nextShotIn = this.fireRate;
    return bullet;
  }

  fastFiring() {
    this.sound.play();
    var bullet = new PlayerBullet(this.plane.x + 5, this.plane.y - 60, 60, 90, this.bullet1, this.plane, this.enemy, false);
    this.nextShotIn = this.fireRate;
    this.counter++;
    console.log(this.counter);
    return bullet;
  }
  getY() {
    return this.y;
  }
  getX() {
    return this.x;
  }
  getToSplice() {
    return this.toSplice;
  }
}

class EnemyBullet extends Sprite {
  constructor(x, y, w, h, img, plane, myGame) {
    super();
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.img = img;
    this.bullet = new Image();
    this.bullet.src = "images/lazer1.png";
    this.myGame = myGame;
    this.plane = plane;
    this.destoyed = false;
    this.toSplice = false;
    this.fireRate = 0;
    this.nextShotIn = 0;
  }

  update() {
    this.y += 4.5;
    if (82 in keysDown) {
      this.myGame.gameEnded = true;
    }
    this.firing();
    if (this.y > 700) {
      this.toSplice = true;
      return true;
    }

  }
  

  draw(ctx) {
    if (!this.first) {
      ctx.drawImage(this.img, this.x, this.y, this.w, this.h);
    }
  }

  fireBullet() {
    if (this.nextShotIn === 0) {
      var enemyGun = new EnemyBullet(this.plane.getX() + 35, this.plane.getY() + 50, 30, 50, this.bullet, this.plane, this.myGame);
      this.nextShotIn = this.fireRate;
      this.myGame.addSprite(enemyGun);
      this.myGame.enemyBullets.push(enemyGun);
    }
  }
  firing() {
    this.fireRate++;
    if (!this.plane.destoyed) {
      if (this.fireRate > 125)
        this.fireBullet();

      if (this.fireRate % 126 == 0)
        this.fireRate = 0;
    }
  }
  getY() {
    return this.y;
  }
  getX() {
    return this.x;
  }
  getToSplice() {
    return this.toSplice;
  }
}

class spriteImage {

  constructor(options) {
      this.framex = 0,
      this.framey = 0,
      this.tickCountx = 0,
      this.tickCounty = 0,
    this.ticksPerFrame = options.ticksPerFrame || 0,
    this.numberOfFramesx = options.numberOfFramesx || 1,
    this.numberOfFramesy = options.numberOfFramesy || 1;
    this.finished = false;
    this.width = options.width;
    this.height = options.height;
    this.image = options.image;
    this.x = options.x;
    this.y = options.y;
    this.modifier = options.modifier || 1;
  }
  update() {

    this.tickCountx += 1;

    if (this.tickCounty % this.numberOfFramesy == 0)
      this.tickCounty = 0;
    this.tickCounty++;


    if (this.tickCountx > this.ticksPerFrame) {

      this.tickCountx = 0;

      if (this.framex < this.numberOfFramesx - 1) {
        this.framex += 1;
      } else {
        this.framex = 0;
      }
      if (this.framey < this.numberOfFramesy - 1) {
        this.framey += 1;
      } else {
        this.framey = 0;
      }
    }
    if (this.framex == this.numberOfFramesx - 1 && this.framey == this.numberOfFramesy - 1) {
      return true;
    }
  };

  drawImage1 = function (ctx) {

    ctx.drawImage(
      this.image,
      this.framex * this.width / this.numberOfFramesx,
      this.framey * this.height / this.numberOfFramesy,
      this.width / this.numberOfFramesx,
      this.height / this.numberOfFramesy,
      this.x,
      this.y,
      75 * this.modifier,
      75 * this.modifier);
  };
  draw(ctx) {
    this.drawImage1(ctx);
  }
}

class DrawImage extends Sprite {
  constructor(x, y, w, h, img, myGame, mod = 1) {
    super();
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.img = img;
    this.mover = false;
    this.destoyed = false;
    this.myGame = myGame;
    this.mod = mod;
  }
  setMover(mover) {
    this.mover = mover;
  }
  update() {

    if (!this.mover) {
      if (this.destoyed) {
        return true;
      }
    } else {
      this.y += 2;
      if (this.y > 700) {
        if (this.mod == 1)
          this.y = Math.random() * (-1500 + 500) - 500;
        else {
          this.y = -600;
        }
      }
    }
  }
  draw(ctx) {
    if (this.mod == 0) {
      ctx.font = "30px  monospace";
      ctx.fillStyle = "#A93226";
      ctx.fillText(`Press R to restart`, this.x + 200, this.y + 400);
      ctx.fillText(`Your Score was: ${this.myGame.score} pts`, this.x + 200, this.y + 480);
      ctx.fillText(`You Killed: ${this.myGame.enemiesKilled} enemies`, this.x + 200, this.y + 440);
    }
    ctx.drawImage(this.img, this.x, this.y, this.w, this.h);
  }
}


class consumable extends Sprite {
  constructor(x, y, w, h,myGame, player, consumableType) {
    super();
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.shield = new Image();
    this.shield.src = "images/shield.png";
    this.powerUp = new Image();
    this.powerUp.src = "images/powerUp.png";
    this.mover = false;
    this.myGame = myGame;
    this.player = player;
    this.consumedSound = new Audio();
    this.consumedSound.src = "sound/consumed.flac";
    this.consumableType = consumableType;
  }
  update() {
      this.y += 2;
      if (this.y > 700) {
        this.consumed = true;
      }
      if((this.y + this.h - 60> this.player.y && this.y < this.player.y + 100) && 
         (this.x + this.w > this.player.x && this.x < this.player.x + 100))
         {
          if(this.consumableType == 2)
          {
            this.myGame.sprites[19].fireRateMode = 1;
          }
          else{
              this.myGame.sprites[18].invincible = true;
          }
            this.consumedSound.play();
            return true;
         }
  }
  draw(ctx) {
    if(this.consumableType == 1)
    {
    ctx.drawImage(this.shield, this.x, this.y, this.w, this.h);
    }else{
    ctx.drawImage(this.powerUp, this.x, this.y, this.w, this.h);
  }
 }
}


class EnemyBoss extends Sprite {
  constructor(x, y, w, h, myGame) {
    super();
    this.x = x;
    this.y = y;
    this.w = w;
    this.myGame = myGame;
    this.h = h;
    this.deflectX = 1;
    this.enemyImg = new Image();
    this.enemyImg.src = "images/enemyboss.png";
    this.enemyImg0 = new Image();
    this.enemyImg0.src = "images/plane1.png";
    this.enemyImg1 = new Image();
    this.enemyImg1.src = "images/plane2.png";
    this.enemyImg2 = new Image();
    this.enemyImg2.src = "images/plane3.png";
    this.bullet1 = new Image();
    this.bullet1.src = "images/lazer1.png";
    this.healthbar1 = new Image();
    this.healthbar1.src = "images/healthbar1.png";
    this.healthbar2 = new Image();
    this.healthbar2.src = "images/healthbar2.png";
    this.healthbar3 = new Image();
    this.healthbar3.src = "images/healthbar3.png";
    this.healthbar4 = new Image();
    this.healthbar4.src = "images/healthbar4.png";
    this.destoyed = false;
    this.tickCount = 0;
    this.fx = x;
    this.health = 200;
    myGame.playing.pause();
    this.soundTrack = new Audio("sound/bossFight.ogg");
    this.soundTrack.volume = 0.6;
    this.soundTrack.play();
    var enemyGun = new BossBullet(300, 300, 50, 60, this.bullet1, this, this.myGame, true);
    this.myGame.addSprite(enemyGun);
    this.destoyedSound = new Audio("sound/bossExplosion.wav");
    this.time = 0;
    this.firstPhase = false;
  }
  update() {
    if(this.soundTrack.duration > 0)
      {
        this.soundTrack.play();
      }
      if(this.y < 100 && !this.firstPhase)
      {
        this.y += 1.35;
        this.x += .155;
      }else
      this.firstPhase = true;


      this.tickCount++;
      if(this.tickCount == 150)
        this.tickCount = 0;
      // if (this.x > this.fx + 200 || this.x < this.fx - 200) {
      //   this.deflectX = -this.deflectX;
      // }
      // this.x += this.deflectX;
      if(this.firstPhase)
      {
      this.time++;
      this.x = Math.sin((this.time/200)) * 250 + 275;
      this.y = Math.sin((this.time/100)) * 100 + 100;
      }
      if (this.destoyed) {
        var explosion = new spriteImage({
          width: 791,
          height: 315,
          x: this.x,
          y: this.y,
          image: explosionImg,
          numberOfFramesx: 5,
          numberOfFramesy: 2,
          ticksPerFrame: 15,
          modifier: 5
        })
        var bg = new Image();
        bg.src = "images/win1.png";
        var bg = new DrawImage(320, -500, 400, 130, bg, this.myGame);
        bg.setMover(true);
        this.myGame.addSprite(bg);
        this.myGame.gameWon = true;
        this.myGame.addSprite(explosion);
        this.destoyedSound.play();
        this.toSplice = true;
        if(!this.myGame.gameOver)
        this.myGame.gameWon = true;
        return true;
      }
      var value = Math.random();
      if(value < 0.001){
        if(value < 0.0005)
            {
              var powerUp = new consumable(this.x + this.w/2, this.y +this.h/2, 60, 60,this.myGame, this.myGame.sprites[18], 1);
            }
            else
            {
              var powerUp = new consumable(this.x + this.w/2, this.y +this.h/2, 60, 60,this.myGame, this.myGame.sprites[18], 2);
            }
            this.myGame.sprites.push(powerUp);
          }
      if(this.health < 0)
      {
        this.destoyed = true;
      }

  }
  draw(ctx) {
    if(this.health > 100)
    {
      if(this.health > 150)
        ctx.drawImage(this.healthbar1, this.x + 155, this.y -30, 140, 30);
        else if(this.health > 100 && this.health <  150)
        ctx.drawImage(this.healthbar2, this.x + 155, this.y -30, 140, 30);
        else if(this.health > 50 && this.health <  100)
        ctx.drawImage(this.healthbar3, this.x + 155, this.y -30, 140, 30);
        else
        ctx.drawImage(this.healthbar4, this.x + 155, this.y -30, 140, 30);


        ctx.drawImage(this.enemyImg, this.x, this.y, this.w, this.h);
    }
    else{
      if(this.tickCount <= 50)
      {
        if(this.health > 150)
        ctx.drawImage(this.healthbar1, this.x + 155, this.y -30, 140, 30);
        else if(this.health > 100 && this.health <  150)
        ctx.drawImage(this.healthbar2, this.x + 155, this.y -30, 140, 30);
        else if(this.health > 50 && this.health <  100)
        ctx.drawImage(this.healthbar3, this.x + 155, this.y -30, 140, 30);
        else
        ctx.drawImage(this.healthbar4, this.x + 155, this.y -30, 140, 30);

        ctx.drawImage(this.enemyImg0, this.x, this.y, this.w, this.h);
      }else if(this.tickCount > 50 && this.tickCount <= 100){
        if(this.health > 150)
        ctx.drawImage(this.healthbar1, this.x + 155, this.y -30, 140, 30);
        else if(this.health > 100 && this.health <  150)
        ctx.drawImage(this.healthbar2, this.x + 155, this.y -30, 140, 30);
        else if(this.health > 50 && this.health <  100)
        ctx.drawImage(this.healthbar3, this.x + 155, this.y -30, 140, 30);
        else
        ctx.drawImage(this.healthbar4, this.x + 155, this.y -30, 140, 30);

        ctx.drawImage(this.enemyImg1, this.x, this.y, this.w, this.h);
      }else{
        if(this.health > 150)
        ctx.drawImage(this.healthbar1, this.x + 155, this.y -30, 140, 30);
        else if(this.health > 100 && this.health <  150)
        ctx.drawImage(this.healthbar2, this.x + 155, this.y -30, 140, 30);
        else if(this.health > 50 && this.health <  100)
        ctx.drawImage(this.healthbar3, this.x + 155, this.y -30, 140, 30);
        else
        ctx.drawImage(this.healthbar4, this.x + 155, this.y -30, 140, 30);
        ctx.drawImage(this.enemyImg2, this.x, this.y, this.w, this.h);
      }
  }
  }
  getY() {
    return this.y;
  }
  getX() {
    return this.x;
  }
}

class BossBullet extends Sprite {
  constructor(x, y, w, h, img, plane, myGame, first) {
    super();
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.img = img;
    this.bullet = new Image();
    this.bullet.src = "images/bossBullet.png";
    this.rocket = new Image();
    this.rocket.src = "images/rocket.png";
    this.myGame = myGame;
    this.plane = plane;
    this.destoyed = false;
    this.toSplice = false;
    this.fireRate = 0;
    this.fireRateRocket = 0;
    this.nextShotInRocket = 0;
    this.nextShotIn = 0;
    this.first = first || false;
    this.firingSound = new Audio("sound/bossFiring.mp3");
    this.firingRocket = new Audio("sound/rocketLunch.mp3");


  }

  update() {
    if (82 in keysDown) {
      this.myGame.gameEnded = true;
    }
    if(this.first){
      this.firing();
    }
    else{
    this.y += 5;
    
    
    if (this.y > 700) {
      this.toSplice = true;
      return true;
    }

  }
}
  

  draw(ctx) {
    if (!this.first) {
      ctx.drawImage(this.img, this.x, this.y, this.w, this.h);
    }
  }

  fireBullet() {
      this.firingSound.play();
      var enemyGun = new BossBullet(this.plane.getX() + 60, this.plane.getY() + 135, 30, 50, this.bullet, this.plane, this.myGame);
      this.nextShotIn = this.fireRate;
      this.myGame.addSprite(enemyGun);
      this.myGame.enemyBullets.push(enemyGun);

      this.myGame.enemyBullets.push(enemyGun);
      var enemyGun = new BossBullet(this.plane.getX() + 195, this.plane.getY() + 170, 30, 50, this.bullet, this.plane, this.myGame);
      this.nextShotIn = this.fireRate;
      this.myGame.addSprite(enemyGun);
      var enemyGun = new BossBullet(this.plane.getX() + 225, this.plane.getY() + 170, 30, 50, this.bullet , this.plane, this.myGame);
      this.nextShotIn = this.fireRate;
      this.myGame.addSprite(enemyGun);
      this.myGame.enemyBullets.push(enemyGun);
      
      this.myGame.enemyBullets.push(enemyGun);
      var enemyGun = new BossBullet(this.plane.getX() + 360, this.plane.getY() + 135, 30, 50, this.bullet, this.plane, this.myGame);
      this.nextShotIn = this.fireRate;
      this.myGame.addSprite(enemyGun);
      this.myGame.enemyBullets.push(enemyGun);
  }
  fireRocket()
  {
    this.firingRocket.play();
    var enemyGun = new BossBullet(this.plane.getX() + 115, this.plane.getY() + 125, 40, 60, this.rocket, this.plane, this.myGame);
    this.nextShotInRocke = this.fireRateRocket
    this.myGame.addSprite(enemyGun);
    var enemyGun = new BossBullet(this.plane.getX() + 300, this.plane.getY() + 125, 40, 60, this.rocket, this.plane, this.myGame);
    this.nextShotInRocke = this.fireRateRocket
      this.myGame.addSprite(enemyGun);
  }
  firing() {
    this.fireRate++;
    this.fireRateRocket++;
    if (!this.plane.destoyed) {
      if (this.fireRate > 80)
        this.fireBullet();

      if(this.fireRateRocket > 700)
        this.fireRocket();

      if (this.fireRate % 81 == 0)
        this.fireRate = 0;

        if (this.fireRateRocket % 701 == 0)
        this.fireRateRocket = 0;
    }
  }
  getY() {
    return this.y;
  }
  getX() {
    return this.x;
  }
  getToSplice() {
    return this.toSplice;
  }
}